﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirstAssignment
{
    public partial class Form2 : Form
    {
        Color selectColor = new Color();
        
        public Form2()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void ToolStripContainer1_BottomToolStripPanel_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click_1(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void SplitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void NtnSubmit_Click(object sender, EventArgs e)
        {
            string userName = tbxName.Text
                , userEmail = tbxEmail.Text
                , userPassword = tbxPassword.Text
                , userGender = this.rbtnFemale.Checked ? this.rbtnFemale.Text : this.rbtnOther.Checked ? this.rbtnOther.Text : this.rbtnMale.Text
                , userColor = this.selectColor.ToString()
                , userBirthDate = this.dtpBirthDate.Value.ToString()
                , userCountry = this.cbxCountry.SelectedItem.ToString();

            string output = "Name: " + userName + "\n Email: " + userEmail + " \nPassword: " + userPassword + " \nGender: " + userGender + " \nColor: " + userColor + " \nBirth Date: " + userBirthDate + " \nCountry: " + userCountry + "";

            if(validate.CheckInput(userName) && validate.CheckPassword(userPassword) && validate.CheckEmail(userEmail))
            {
                this.lblOutput.Text = output;
                return;
            }
            this.lblOutput.Text = "Please Enter Valid Data";

        }

        private void CChooser_Click(object sender, EventArgs e)
        {
            if(this.cDialog.ShowDialog() == DialogResult.OK)
            {
                this.selectColor = cDialog.Color;
            }
        }

        private void LblOutput_Click(object sender, EventArgs e)
        {

        }
    }

    class validate
    {
        public static bool CheckInput(string s)
        {
            if (s.Trim() == "")
                return false;

            return true;

        }

        public static bool CheckPassword(string s)
        {
            if (s.Length < 8)
                return false;

            return true;

        }

        public static bool CheckEmail(string s)
        {
            if (s.Contains("@gmail.com"))
                return true;
            else if (s.Contains("@hotmail.com"))
                return true;

            return false;
        }




    }
}
